##2015-11-24 - 7.0.0
###Summary

- Initial release of the puppet-aodh module
